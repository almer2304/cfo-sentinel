"""
core/orchestrator.py
CFO Sentinel — LangGraph Orchestrator

Pipeline utama yang menghubungkan semua 6 agent.

Flow:
  Parser → Categorizer → Analyst → Anomaly (Critic)
    ↓ jika trigger_reflection (max 2x): kembali ke Analyst
  Analyst + Anomaly → Scenario (paralel dalam 1 LLM call)
  Anomaly + Scenario → Advisor
  Advisor → Dashboard (via PipelineState)

Termination:
  - MAX_REFLECTION = 2 (hard limit)
  - Timeout 30s per agent (via llm_client retry)
  - Fallback rule-based jika LLM gagal
"""

import uuid
import os
from datetime import datetime
from typing import Literal

# pyrefly: ignore [missing-import]
from langgraph.graph import StateGraph, END

from core.schemas import PipelineState
from core.database import (
    init_database,
    save_transactions,
    save_analytics,
    save_anomalies,
    save_recommendations,
    log_agent_step,
)
from core.memory import (
    save_session_snapshot,
    update_baselines_from_transactions,
)
from agents.parser_agent import run_parser_agent
from agents.categorizer_agent import run_categorizer_agent
from agents.analyst_agent import run_analyst_agent
from agents.anomaly_agent import run_anomaly_agent
from agents.scenario_agent import run_scenario_agent
from agents.advisor_agent import run_advisor_agent


# ══════════════════════════════════════════════════════════════════
# NODE FUNCTIONS — setiap node menerima & mengembalikan PipelineState
# ══════════════════════════════════════════════════════════════════

def node_parser(state: PipelineState) -> PipelineState:
    """Node 1: Parse teks bebas → transaksi terstruktur."""
    print(f"🔍 [Parser] Processing input...")
    start = datetime.now()

    try:
        output = run_parser_agent(
            session_id=state.session_id,
            raw_input=state.raw_input,
        )
        state.parser_output = output

        log_agent_step(
            session_id=state.session_id,
            agent_name="parser",
            step=1,
            input_summary=f"Input: {len(state.raw_input)} chars",
            reasoning=f"Parsed {output.total_parsed} transactions. "
                      f"Has ambiguity: {output.has_ambiguity}",
            output_summary=f"Total parsed: {output.total_parsed}",
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ Parsed {output.total_parsed} transactions")
        if output.has_ambiguity:
            print(f"  ⚠️  Ambiguity detected: {output.ambiguity_notes}")

    except Exception as e:
        state.errors.append(f"[Parser] {str(e)}")
        state.warnings.append("Parser gagal — pipeline dihentikan.")
        print(f"  ❌ Parser error: {e}")

    state.current_step = "parser_done"
    return state


def node_categorizer(state: PipelineState) -> PipelineState:
    """Node 2: Kategorisasi transaksi."""
    if not state.parser_output or state.parser_output.total_parsed == 0:
        state.warnings.append("Tidak ada transaksi untuk dikategorisasi.")
        state.current_step = "categorizer_done"
        return state

    print(f"🏷️  [Categorizer] Categorizing {state.parser_output.total_parsed} transactions...")
    start = datetime.now()

    try:
        output = run_categorizer_agent(state.parser_output)
        state.categorizer_output = output

        # Simpan transaksi ke database
        tx_dicts = [t.model_dump() if hasattr(t, "model_dump") else dict(t)
                    for t in output.transactions]
        saved = save_transactions(tx_dicts, state.session_id)

        log_agent_step(
            session_id=state.session_id,
            agent_name="categorizer",
            step=2,
            input_summary=f"{state.parser_output.total_parsed} transactions",
            reasoning=f"Categories found: {output.categories_found}. "
                      f"Recurring: {output.recurring_count}",
            output_summary=f"Income: Rp {output.total_income:,.0f} | "
                           f"Expense: Rp {output.total_expense:,.0f}",
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ Categories: {output.categories_found}")
        print(f"  📊 Income: Rp {output.total_income:,.0f} | "
              f"Expense: Rp {output.total_expense:,.0f}")

    except Exception as e:
        state.errors.append(f"[Categorizer] {str(e)}")
        print(f"  ❌ Categorizer error: {e}")

    state.current_step = "categorizer_done"
    return state


def node_analyst(state: PipelineState) -> PipelineState:
    """Node 3: Kalkulasi metrik keuangan + narasi."""
    if not state.categorizer_output:
        state.warnings.append("Tidak ada data kategorisasi untuk dianalisis.")
        state.current_step = "analyst_done"
        return state

    reflection_num = state.reflection_count
    label = "Analyst" if reflection_num == 0 else f"Analyst (reflection #{reflection_num})"
    print(f"📈 [{label}] Computing financial metrics...")
    start = datetime.now()

    try:
        output = run_analyst_agent(
            categorizer_output=state.categorizer_output,
            current_cash_balance=state.current_cash_balance,
            business_type=state.business_type,
        )
        state.analyst_output = output

        log_agent_step(
            session_id=state.session_id,
            agent_name="analyst",
            step=3 + reflection_num,
            input_summary=f"Cash balance: Rp {state.current_cash_balance:,.0f}",
            reasoning=f"Reflection #{reflection_num}. "
                      f"Health score: {output.health_score.current:.0f}. "
                      f"Runway: {output.runway_days.expected:.0f} days.",
            output_summary=f"Health: {output.health_score.current:.0f}/100 | "
                           f"Runway: {output.runway_days.expected:.0f}d",
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ Health Score: {output.health_score.current:.0f}/100 "
              f"({output.health_score.status})")
        print(f"  📅 Runway: {output.runway_days.expected:.0f} days")

    except Exception as e:
        state.errors.append(f"[Analyst] {str(e)}")
        print(f"  ❌ Analyst error: {e}")

    state.current_step = "analyst_done"
    return state


def node_anomaly(state: PipelineState) -> PipelineState:
    """Node 4: Deteksi anomali + Critic Pattern validation."""
    if not state.analyst_output or not state.categorizer_output:
        state.warnings.append("Tidak ada data analisis untuk deteksi anomali.")
        state.current_step = "anomaly_done"
        return state

    print(f"🔎 [Anomaly] Detecting anomalies + validating analyst output...")
    start = datetime.now()

    try:
        output = run_anomaly_agent(
            analyst_output=state.analyst_output,
            categorizer_output=state.categorizer_output,
            business_type=state.business_type,
        )
        state.anomaly_output = output

        # Simpan anomali ke database
        anomaly_dicts = [a.model_dump() if hasattr(a, "model_dump") else dict(a)
                         for a in output.anomalies]
        if anomaly_dicts:
            save_anomalies(anomaly_dicts, state.session_id)

        log_agent_step(
            session_id=state.session_id,
            agent_name="anomaly",
            step=4,
            input_summary=f"Analyst health score: {state.analyst_output.health_score.current:.0f}",
            reasoning=f"Found {output.total_anomalies} anomalies. "
                      f"Risk: {output.overall_risk_level}. "
                      f"Trigger reflection: {output.trigger_reflection}",
            output_summary=f"Anomalies: {output.total_anomalies} | "
                           f"Risk: {output.overall_risk_level}",
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ Anomalies found: {output.total_anomalies} "
              f"(HIGH: {output.high_severity_count})")
        print(f"  🚦 Risk level: {output.overall_risk_level}")

        if output.trigger_reflection:
            print(f"  🔄 Critic flag: requesting Analyst reflection")

    except Exception as e:
        state.errors.append(f"[Anomaly] {str(e)}")
        print(f"  ❌ Anomaly error: {e}")

    state.current_step = "anomaly_done"
    return state


def node_scenario(state: PipelineState) -> PipelineState:
    """
    Node 5: Scenario Simulation.
    Default scenario: revenue drop 20% (most common UMKM risk).
    User bisa override dari dashboard.
    """
    if not state.analyst_output or not state.categorizer_output:
        state.warnings.append("Tidak ada data untuk simulasi skenario.")
        state.current_step = "scenario_done"
        return state

    print(f"🎯 [Scenario] Running what-if simulation...")
    start = datetime.now()

    try:
        output = run_scenario_agent(
            analyst_output=state.analyst_output,
            categorizer_output=state.categorizer_output,
            scenario_description="Penjualan turun 20% bulan depan",
            parameter_name="revenue",
            parameter_change_pct=-20.0,
        )
        state.scenario_output = output

        log_agent_step(
            session_id=state.session_id,
            agent_name="scenario",
            step=5,
            input_summary="Default scenario: revenue -20%",
            reasoning=f"New runway: {output.new_runway.expected:.0f} days. "
                      f"New health: {output.new_health_score:.0f}. "
                      f"Cuttable: Rp {output.total_cuttable_amount:,.0f}",
            output_summary=f"Runway: {output.new_runway.expected:.0f}d | "
                           f"Health: {output.new_health_score:.0f}/100",
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ New runway: {output.new_runway.expected:.0f} days")
        print(f"  💰 Cuttable costs: Rp {output.total_cuttable_amount:,.0f}")

    except Exception as e:
        state.errors.append(f"[Scenario] {str(e)}")
        state.warnings.append("Simulasi skenario gagal — dilanjutkan tanpa scenario.")
        print(f"  ❌ Scenario error: {e}")

    state.current_step = "scenario_done"
    return state


def node_advisor(state: PipelineState) -> PipelineState:
    """Node 6: Strategic recommendation + early warning."""
    if not state.analyst_output or not state.anomaly_output:
        state.warnings.append("Data tidak cukup untuk rekomendasi advisor.")
        state.current_step = "advisor_done"
        return state

    print(f"🧠 [Advisor] Generating strategic recommendations...")
    start = datetime.now()

    try:
        output = run_advisor_agent(
            analyst_output=state.analyst_output,
            anomaly_output=state.anomaly_output,
            scenario_output=state.scenario_output,
        )
        state.advisor_output = output

        # Simpan rekomendasi ke database
        rec_dicts = [
            {
                "priority":      item.priority,
                "title":         item.title,
                "description":   item.description,
                "impact":        item.estimated_impact,
                "urgency":       item.urgency,
                "category":      item.category,
                "early_warning": (
                    output.early_warning.message
                    if output.has_early_warning and output.early_warning
                    else None
                ),
                "confidence_min": None,
                "confidence_max": None,
            }
            for item in output.action_items
        ]
        if rec_dicts:
            save_recommendations(rec_dicts, state.session_id)

        log_agent_step(
            session_id=state.session_id,
            agent_name="advisor",
            step=6,
            input_summary=f"Anomaly risk: {state.anomaly_output.overall_risk_level}",
            reasoning=f"Actions: {len(output.action_items)}. "
                      f"Early warning: {output.has_early_warning}. "
                      f"Conflict detected: {output.conflict_detected}",
            output_summary=output.executive_summary[:120],
            duration_ms=int((datetime.now() - start).total_seconds() * 1000),
            status="success",
        )

        print(f"  ✅ Actions generated: {len(output.action_items)}")
        if output.has_early_warning and output.early_warning:
            print(f"  🚨 Early warning: {output.early_warning.message[:80]}...")

    except Exception as e:
        state.errors.append(f"[Advisor] {str(e)}")
        print(f"  ❌ Advisor error: {e}")

    state.current_step = "advisor_done"
    return state


def node_finalize(state: PipelineState) -> PipelineState:
    """
    Node final: simpan snapshot bulanan, update baselines.
    Dipanggil setelah semua agent selesai.
    """
    print(f"💾 [Finalize] Saving session data...")

    try:
        if state.analyst_output:
            # Simpan analytics ke DB
            analytics_dict = {
                "period_start":          state.analyst_output.period_start,
                "period_end":            state.analyst_output.period_end,
                "total_income":          state.analyst_output.total_income,
                "total_expense":         state.analyst_output.total_expense,
                "net_cashflow":          state.analyst_output.net_cashflow,
                "cash_balance":          state.analyst_output.cash_balance,
                "burn_rate_daily":       state.analyst_output.burn_rate_daily,
                "burn_rate_monthly":     state.analyst_output.burn_rate_monthly,
                "gross_margin":          state.analyst_output.gross_margin,
                "runway_days":           state.analyst_output.runway_days.expected,
                "revenue_consistency":   state.analyst_output.revenue_consistency,
                "health_score":          state.analyst_output.health_score.current,
                "health_score_prev":     state.analyst_output.health_score.previous_month,
                "health_score_industry": state.analyst_output.health_score.industry_average,
                "health_score_threshold": state.analyst_output.health_score.danger_threshold,
                "narrative":             state.analyst_output.narrative,
                "business_type":         state.analyst_output.business_type,
                "forecast_30d":          [
                    fp.model_dump() for fp in state.analyst_output.forecast_30d
                ],
            }
            save_analytics(analytics_dict, state.session_id)

            # Update persistent memory
            save_session_snapshot(analytics_dict, state.business_type)
            year_month = datetime.now().strftime("%Y-%m")
            update_baselines_from_transactions(state.business_type, year_month)

        print(f"  ✅ Session {state.session_id[:8]}... saved")

    except Exception as e:
        state.errors.append(f"[Finalize] {str(e)}")
        print(f"  ❌ Finalize error: {e}")

    state.current_step = "done"
    return state


# ══════════════════════════════════════════════════════════════════
# CONDITIONAL EDGES — Routing logic
# ══════════════════════════════════════════════════════════════════

def should_reflect(state: PipelineState) -> Literal["reflect", "continue"]:
    """
    Setelah Anomaly agent, cek apakah Analyst perlu re-run.
    MAX_REFLECTION = 2 (hard limit dari AI_CONTEXT.md).
    """
    if (
        state.anomaly_output
        and state.anomaly_output.trigger_reflection
        and state.reflection_count < state.max_reflection
    ):
        state.reflection_count += 1
        print(f"  🔄 Reflection triggered "
              f"({state.reflection_count}/{state.max_reflection})")
        return "reflect"

    return "continue"


# ══════════════════════════════════════════════════════════════════
# GRAPH CONSTRUCTION
# ══════════════════════════════════════════════════════════════════

def build_pipeline() -> StateGraph:
    """Bangun LangGraph pipeline. Dipanggil sekali saat startup."""
    graph = StateGraph(PipelineState)

    # Tambah semua nodes
    graph.add_node("parser",      node_parser)
    graph.add_node("categorizer", node_categorizer)
    graph.add_node("analyst",     node_analyst)
    graph.add_node("anomaly",     node_anomaly)
    graph.add_node("scenario",    node_scenario)
    graph.add_node("advisor",     node_advisor)
    graph.add_node("finalize",    node_finalize)

    # Edge utama (sequential)
    graph.add_edge("parser",      "categorizer")
    graph.add_edge("categorizer", "analyst")
    graph.add_edge("analyst",     "anomaly")

    # Conditional edge: Critic Pattern (reflection loop)
    graph.add_conditional_edges(
        "anomaly",
        should_reflect,
        {
            "reflect":  "analyst",    # kembali ke Analyst jika perlu reflection
            "continue": "scenario",   # lanjut ke Scenario jika clear
        },
    )

    graph.add_edge("scenario",  "advisor")
    graph.add_edge("advisor",   "finalize")
    graph.add_edge("finalize",  END)

    # Entry point
    graph.set_entry_point("parser")

    return graph.compile()


# ══════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════

# Compile pipeline sekali saat module di-import
_pipeline = None


def get_pipeline():
    """Lazy-init pipeline (avoid import-time errors)."""
    global _pipeline
    if _pipeline is None:
        _pipeline = build_pipeline()
    return _pipeline


def run_pipeline(
    raw_input: str,
    business_type: str = "general",
    current_cash_balance: float = 0.0,
    session_id: str | None = None,
    is_demo_mode: bool = False,
) -> PipelineState:
    """
    Entry point utama untuk menjalankan seluruh pipeline CFO Sentinel.

    Args:
        raw_input:            Teks transaksi dari user (bebas format)
        business_type:        Jenis bisnis: kuliner, fashion, jasa, retail, general
        current_cash_balance: Saldo kas saat ini (Rupiah)
        session_id:           ID sesi (auto-generate jika None)
        is_demo_mode:         Jika True, gunakan cached output (hemat token)

    Returns:
        PipelineState: State final berisi semua output agent
    """
    # Inisialisasi database jika belum ada
    init_database()

    if session_id is None:
        session_id = str(uuid.uuid4())

    initial_state = PipelineState(
        session_id=session_id,
        raw_input=raw_input,
        business_type=business_type,
        current_cash_balance=current_cash_balance,
        is_demo_mode=is_demo_mode,
    )

    print(f"\n{'='*60}")
    print(f"🚀 CFO Sentinel Pipeline Starting")
    print(f"   Session: {session_id[:8]}...")
    print(f"   Business: {business_type}")
    print(f"   Balance: Rp {current_cash_balance:,.0f}")
    print(f"{'='*60}\n")

    pipeline = get_pipeline()
    final_state = pipeline.invoke(initial_state)

    print(f"\n{'='*60}")
    print(f"✅ Pipeline Complete")
    if final_state.get("errors") if isinstance(final_state, dict) else final_state.errors:
        errors = final_state.get("errors") if isinstance(final_state, dict) else final_state.errors
        print(f"   ⚠️  Errors: {len(errors)}")
    print(f"{'='*60}\n")

    # LangGraph returns dict, convert back to PipelineState
    if isinstance(final_state, dict):
        return PipelineState(**final_state)
    return final_state


# ══════════════════════════════════════════════════════════════════
# ENTRY POINT — Quick test
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    test_input = (
        "kemarin beli bahan baku 1.5jt, bayar listrik 450rb, "
        "terima bayaran dari pelanggan 3.2jt, "
        "bayar gaji karyawan 2jt, beli kemasan 300rb"
    )

    result = run_pipeline(
        raw_input=test_input,
        business_type="kuliner",
        current_cash_balance=5_000_000,
    )

    print("\n📊 HASIL ANALISIS:")
    if result.advisor_output:
        print(f"\nExecutive Summary:\n{result.advisor_output.executive_summary}")
        if result.advisor_output.has_early_warning and result.advisor_output.early_warning:
            print(f"\n⚠️  Early Warning: {result.advisor_output.early_warning.message}")
        print(f"\nAction Items ({len(result.advisor_output.action_items)}):")
        for item in result.advisor_output.action_items[:3]:
            print(f"  {item.priority}. [{item.urgency}] {item.title}")
    else:
        print("Advisor output tidak tersedia.")
