"""
core/schemas.py
CFO Sentinel — Pydantic Schemas (Contract Antar Agent)

Ini adalah "kontrak" resmi antara setiap agent.
Setiap agent WAJIB output sesuai schema ini.
Jika tidak sesuai, Pydantic akan throw ValidationError
sebelum data diteruskan ke agent berikutnya.
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional, Literal
from datetime import datetime


# ══════════════════════════════════════════════════════════════════
# SHARED — Dipakai di banyak tempat
# ══════════════════════════════════════════════════════════════════

class ConfidenceRange(BaseModel):
    """Range kepercayaan untuk output yang mengandung uncertainty."""
    minimum: float = Field(..., ge=0)
    expected: float = Field(..., ge=0)
    maximum: float = Field(..., ge=0)
    assumption: str = ""

    @field_validator("maximum")
    @classmethod
    def max_gte_min(cls, v, info):
        if "minimum" in info.data and v < info.data["minimum"]:
            raise ValueError("maximum harus >= minimum")
        return v


# ══════════════════════════════════════════════════════════════════
# AGENT 1 — Parser Agent
# ══════════════════════════════════════════════════════════════════

class ParsedTransaction(BaseModel):
    """
    Satu transaksi yang berhasil di-parse dari input user.
    Output dari Parser Agent.
    """
    date: str = Field(
        ...,
        description="Format YYYY-MM-DD",
        pattern=r"^\d{4}-\d{2}-\d{2}$"
    )
    amount: float = Field(..., gt=0, description="Selalu positif")
    type: Literal["income", "expense"]
    description: str = Field(..., min_length=1)
    is_business: bool = Field(
        default=True,
        description="True jika ini transaksi bisnis, False jika personal"
    )
    confidence: float = Field(
        default=1.0,
        ge=0.0,
        le=1.0,
        description="Seberapa yakin agent dengan hasil parse ini"
    )
    needs_clarification: bool = Field(
        default=False,
        description="True jika agent tidak yakin dan perlu konfirmasi user"
    )
    clarification_question: Optional[str] = Field(
        default=None,
        description="Pertanyaan ke user jika needs_clarification=True"
    )


class ParserOutput(BaseModel):
    """Output lengkap dari Parser Agent untuk satu sesi input."""
    session_id: str
    transactions: list[ParsedTransaction]
    raw_input: str
    total_parsed: int
    has_ambiguity: bool = False
    ambiguity_notes: list[str] = []

    @field_validator("total_parsed")
    @classmethod
    def total_matches_list(cls, v, info):
        if "transactions" in info.data:
            actual = len(info.data["transactions"])
            if v != actual:
                raise ValueError(
                    f"total_parsed ({v}) tidak cocok "
                    f"dengan jumlah transaksi ({actual})"
                )
        return v


# ══════════════════════════════════════════════════════════════════
# AGENT 2 — Categorizer Agent
# ══════════════════════════════════════════════════════════════════

# Kategori valid yang diakui sistem
VALID_CATEGORIES = [
    "Bahan Baku",
    "Operasional",
    "Marketing",
    "SDM",           # Gaji, tunjangan, dll
    "Penjualan",     # Untuk income
    "Piutang",       # Pembayaran piutang masuk
    "Utang",         # Pembayaran utang keluar
    "Investasi",     # Pembelian aset
    "Lain-lain",
]

VALID_SUB_CATEGORIES = {
    "Bahan Baku":   ["Makanan", "Minuman", "Kemasan", "Bahan Mentah", "Lainnya"],
    "Operasional":  ["Sewa", "Listrik", "Air", "Internet", "Transport", "Lainnya"],
    "Marketing":    ["Iklan Digital", "Print", "Promosi", "Event", "Lainnya"],
    "SDM":          ["Gaji", "Tunjangan", "BPJS", "Lembur", "Lainnya"],
    "Penjualan":    ["Produk", "Jasa", "Komisi", "Lainnya"],
    "Piutang":      ["Pelanggan", "Lainnya"],
    "Utang":        ["Supplier", "Bank", "Pinjaman", "Lainnya"],
    "Investasi":    ["Peralatan", "Renovasi", "Teknologi", "Lainnya"],
    "Lain-lain":    ["Lainnya"],
}


class CategorizedTransaction(BaseModel):
    """Transaksi yang sudah dikategorikan oleh Categorizer Agent."""
    # Semua field dari ParsedTransaction
    date: str
    amount: float
    type: Literal["income", "expense"]
    description: str
    is_business: bool = True
    confidence: float = 1.0

    # Tambahan dari Categorizer
    category: str = Field(..., description="Kategori utama")
    sub_category: str = Field(..., description="Sub-kategori")
    is_recurring: bool = Field(
        default=False,
        description="True jika ini pengeluaran/pemasukan rutin"
    )
    categorization_confidence: float = Field(
        default=1.0,
        ge=0.0,
        le=1.0
    )

    @field_validator("category")
    @classmethod
    def category_must_be_valid(cls, v):
        if v not in VALID_CATEGORIES:
            raise ValueError(
                f"Kategori '{v}' tidak valid. "
                f"Pilih dari: {VALID_CATEGORIES}"
            )
        return v


class CategorizerOutput(BaseModel):
    """Output lengkap dari Categorizer Agent."""
    session_id: str
    transactions: list[CategorizedTransaction]
    total_income: float = 0
    total_expense: float = 0
    categories_found: list[str] = []
    recurring_count: int = 0


# ══════════════════════════════════════════════════════════════════
# AGENT 3 — Financial Analyst Agent
# ══════════════════════════════════════════════════════════════════

class HealthScore(BaseModel):
    """Financial Health Score dengan 3 benchmark."""
    current: float = Field(..., ge=0, le=100)
    previous_month: float = Field(default=0, ge=0, le=100)
    industry_average: float = Field(default=0, ge=0, le=100)
    danger_threshold: float = Field(default=50, ge=0, le=100)
    status: Literal["SAFE", "WARNING", "DANGER"] = "SAFE"
    trend: Literal["UP", "DOWN", "STABLE"] = "STABLE"

    @field_validator("status", mode="before")
    @classmethod
    def compute_status(cls, v, info):
        if "current" in info.data and "danger_threshold" in info.data:
            score = info.data["current"]
            threshold = info.data["danger_threshold"]
            if score < threshold:
                return "DANGER"
            elif score < threshold + 15:
                return "WARNING"
            return "SAFE"
        return v


class ForecastPoint(BaseModel):
    """Satu titik dalam forecast cash flow."""
    day: int
    date: str
    predicted_balance: float
    confidence_min: float
    confidence_max: float


class AnalystOutput(BaseModel):
    """Output lengkap dari Financial Analyst Agent."""
    session_id: str
    period_start: str
    period_end: str

    # Metrik utama
    total_income: float = 0
    total_expense: float = 0
    net_cashflow: float = 0
    cash_balance: float = 0
    burn_rate_daily: float = 0
    burn_rate_monthly: float = 0
    gross_margin: float = 0          # persentase 0-100
    runway_days: ConfidenceRange = Field(
        default_factory=lambda: ConfidenceRange(
            minimum=0, expected=0, maximum=0
        )
    )
    revenue_consistency: float = 0   # 0.0-1.0

    # Health Score
    health_score: HealthScore

    # Forecast
    forecast_30d: list[ForecastPoint] = []

    # Narasi
    narrative: str = ""
    business_type: str = "general"

    # Flag untuk Reflection Loop
    needs_reflection: bool = False
    reflection_note: str = ""


# ══════════════════════════════════════════════════════════════════
# AGENT 4 — Anomaly Detection Agent
# ══════════════════════════════════════════════════════════════════

class Anomaly(BaseModel):
    """Satu anomali yang terdeteksi."""
    category: str
    severity: Literal["HIGH", "MEDIUM", "LOW"]
    current_amount: float
    baseline_amount: float
    deviation_pct: float = Field(
        ...,
        description="Persentase deviasi dari baseline. Positif = di atas normal."
    )
    description: str
    suggested_action: str = ""

    @field_validator("severity", mode="before")
    @classmethod
    def compute_severity(cls, v, info):
        """Auto-compute severity dari deviation_pct jika tidak diset."""
        if isinstance(v, str) and v in ["HIGH", "MEDIUM", "LOW"]:
            return v
        if "deviation_pct" in info.data:
            dev = abs(info.data["deviation_pct"])
            if dev >= 100:
                return "HIGH"
            elif dev >= 50:
                return "MEDIUM"
            return "LOW"
        return "LOW"


class AnomalyOutput(BaseModel):
    """Output lengkap dari Anomaly Detection Agent."""
    session_id: str
    anomalies: list[Anomaly] = []
    total_anomalies: int = 0
    high_severity_count: int = 0

    # Critic Pattern — validasi output Analyst Agent
    analyst_output_valid: bool = True
    analyst_correction: Optional[str] = None
    trigger_reflection: bool = False  # True = minta Analyst re-run

    overall_risk_level: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] = "LOW"

    @field_validator("total_anomalies", mode="before")
    @classmethod
    def sync_total(cls, v, info):
        if "anomalies" in info.data:
            return len(info.data["anomalies"])
        return v


# ══════════════════════════════════════════════════════════════════
# AGENT 5 — Scenario Simulation Agent
# ══════════════════════════════════════════════════════════════════

class CostItem(BaseModel):
    """Item biaya dalam analisis scenario."""
    category: str
    amount: float
    is_cuttable: bool
    cut_potential_pct: float = 0  # berapa % bisa dipotong
    rationale: str = ""


class ScenarioOutput(BaseModel):
    """Output dari Scenario Simulation Agent untuk satu skenario."""
    session_id: str
    scenario_type: str
    parameter_name: str
    parameter_change_pct: float  # negatif = turun, positif = naik

    # Hasil simulasi
    new_runway: ConfidenceRange
    new_health_score: float
    breakeven_day: Optional[int] = None  # hari ke berapa titik kritis

    # Breakdown biaya
    cuttable_costs: list[CostItem] = []
    fixed_costs: list[CostItem] = []
    total_cuttable_amount: float = 0

    # Narasi reasoning
    chain_of_consequences: str = Field(
        ...,
        description="Rantai konsekuensi dari skenario ini, step by step"
    )
    mitigation_steps: str = Field(
        ...,
        description="Langkah mitigasi yang konkret dengan angka"
    )
    mitigation_impact: str = ""  # jika mitigasi dijalankan, efeknya apa


# ══════════════════════════════════════════════════════════════════
# AGENT 6 — Strategic Advisor Agent
# ══════════════════════════════════════════════════════════════════

class ActionItem(BaseModel):
    """Satu item rekomendasi dengan prioritas."""
    priority: int = Field(..., ge=1, description="1 = paling mendesak")
    title: str
    description: str
    urgency: Literal["IMMEDIATE", "THIS_WEEK", "THIS_MONTH"]
    estimated_impact: str = ""
    category: str = ""


class EarlyWarning(BaseModel):
    """Peringatan dini dari Advisor Agent."""
    message: str
    days_until_crisis: Optional[int] = None
    confidence: ConfidenceRange
    trigger_condition: str  # kondisi apa yang memicu warning ini


class AdvisorOutput(BaseModel):
    """Output lengkap dari Strategic Advisor Agent."""
    session_id: str

    # Peringatan dini
    has_early_warning: bool = False
    early_warning: Optional[EarlyWarning] = None

    # Daftar aksi prioritas
    action_items: list[ActionItem] = []

    # Narasi utama
    executive_summary: str = Field(
        ...,
        description="Ringkasan kondisi keuangan dalam 2-3 kalimat"
    )
    detailed_advice: str = Field(
        ...,
        description="Rekomendasi lengkap dengan penjelasan"
    )

    # Awareness uncertainty
    uncertainty_statement: str = Field(
        default="",
        description="Pernyataan tentang asumsi dan keterbatasan analisis"
    )

    # Conflict resolution flag
    # Jika Anomaly dan Scenario bertentangan, Advisor prioritaskan survival
    conflict_detected: bool = False
    conflict_resolution: str = ""


# ══════════════════════════════════════════════════════════════════
# ORCHESTRATOR — State keseluruhan pipeline
# ══════════════════════════════════════════════════════════════════

class PipelineState(BaseModel):
    """
    State yang dibawa oleh Orchestrator sepanjang pipeline.
    Setiap agent membaca dari sini dan menulis hasilnya ke sini.
    """
    session_id: str
    raw_input: str
    business_type: str = "general"
    current_cash_balance: float = 0

    # Output setiap agent (None = belum jalan)
    parser_output: Optional[ParserOutput] = None
    categorizer_output: Optional[CategorizerOutput] = None
    analyst_output: Optional[AnalystOutput] = None
    anomaly_output: Optional[AnomalyOutput] = None
    scenario_output: Optional[ScenarioOutput] = None
    advisor_output: Optional[AdvisorOutput] = None

    # Orchestration control
    reflection_count: int = 0
    max_reflection: int = 2
    current_step: str = "start"
    errors: list[str] = []
    warnings: list[str] = []
    is_demo_mode: bool = False


if __name__ == "__main__":
    # Quick validation test
    print("Testing schemas...")

    tx = ParsedTransaction(
        date="2026-05-07",
        amount=500000,
        type="expense",
        description="Beli bahan baku",
        confidence=0.95,
    )
    print(f"✅ ParsedTransaction valid: {tx.description} - Rp {tx.amount:,.0f}")

    score = HealthScore(
        current=68,
        previous_month=71,
        industry_average=74,
        danger_threshold=50,
        trend="DOWN",
    )
    print(f"✅ HealthScore valid: {score.current}/100 - Status: {score.status}")

    print("\n✅ All schemas validated successfully")