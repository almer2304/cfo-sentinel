"""
agents/analyst_agent.py
CFO Sentinel — Financial Analyst Agent

Menghitung semua metrik keuangan dari data transaksi yang sudah
dikategorisasi. LLM hanya digunakan untuk narasi — semua angka
dari perhitungan Python/SQLite.
"""

from datetime import datetime, timedelta
from core.llm_client import call_llm
from core.prompts import ANALYST_SYSTEM, get_analyst_narrative_prompt
from core.schemas import CategorizerOutput, AnalystOutput, HealthScore, ConfidenceRange, ForecastPoint
from core.memory import get_industry_health_avg, get_monthly_snapshots


def _safe_get(obj, key, default=None):
    """Safely get attribute from Pydantic model or dict."""
    if hasattr(obj, key):
        return getattr(obj, key)
    if isinstance(obj, dict):
        return obj.get(key, default)
    return default


def run_analyst_agent(
    categorizer_output: CategorizerOutput, 
    current_cash_balance: float, 
    business_type: str = "general"
) -> AnalystOutput:
    total_income = categorizer_output.total_income
    total_expense = categorizer_output.total_expense
    net_cashflow = total_income - total_expense
    
    today = datetime.now()
    period_start = today.replace(day=1).strftime("%Y-%m-%d")
    period_end = today.strftime("%Y-%m-%d")
    days_in_period = today.day
    
    burn_rate_daily = total_expense / days_in_period if days_in_period > 0 else total_expense
    burn_rate_monthly = burn_rate_daily * 30
    
    cash_balance = current_cash_balance + net_cashflow
    
    expected_runway = (cash_balance / burn_rate_daily) if burn_rate_daily > 0 else 999
    min_runway = expected_runway * 0.8
    max_runway = expected_runway * 1.2
    
    if total_income > 0:
        gross_margin = ((total_income - total_expense) / total_income * 100)
    else:
        gross_margin = 0
    gross_margin = max(0, gross_margin)
    
    hs_base = min(100, max(0, 50 + (gross_margin / 2) + (expected_runway / 3)))
    
    industry_avg = get_industry_health_avg(business_type)
    
    snapshots = get_monthly_snapshots(business_type, last_n_months=1)
    prev_score = snapshots[0].get("health_score", industry_avg) if snapshots else industry_avg
    
    trend = "STABLE"
    if hs_base > prev_score + 5:
        trend = "UP"
    elif hs_base < prev_score - 5:
        trend = "DOWN"
        
    health_score = HealthScore(
        current=hs_base,
        previous_month=prev_score,
        industry_average=industry_avg,
        danger_threshold=50,
        trend=trend
    )
    
    forecast = []
    current_b = cash_balance
    for i in range(1, 31):
        f_date = (today + timedelta(days=i)).strftime("%Y-%m-%d")
        current_b -= burn_rate_daily
        forecast.append(ForecastPoint(
            day=i,
            date=f_date,
            predicted_balance=current_b,
            confidence_min=current_b * 0.9,
            confidence_max=current_b * 1.1
        ))
        
    # Hitung pengeluaran per kategori — handle baik Pydantic maupun dict
    category_breakdown = []
    for c in categorizer_output.categories_found:
        total = sum(
            _safe_get(t, "amount", 0)
            for t in categorizer_output.transactions
            if _safe_get(t, "category") == c
        )
        category_breakdown.append({"category": c, "total": total})

    prompt_data = {
        "period_start": period_start,
        "period_end": period_end,
        "total_income": total_income,
        "total_expense": total_expense,
        "net_cashflow": net_cashflow,
        "cash_balance": cash_balance,
        "burn_rate_daily": burn_rate_daily,
        "runway_expected": expected_runway,
        "gross_margin": gross_margin,
        "health_score": hs_base,
        "health_score_prev": prev_score,
        "health_score_industry": industry_avg,
        "business_type": business_type,
        "category_breakdown": category_breakdown
    }
    
    prompt = get_analyst_narrative_prompt(prompt_data)
    
    narrative, metadata = call_llm(
        agent_name="analyst",
        system_prompt=ANALYST_SYSTEM,
        user_message=prompt,
        response_format="text"
    )
    
    output = AnalystOutput(
        session_id=categorizer_output.session_id,
        period_start=period_start,
        period_end=period_end,
        total_income=total_income,
        total_expense=total_expense,
        net_cashflow=net_cashflow,
        cash_balance=cash_balance,
        burn_rate_daily=burn_rate_daily,
        burn_rate_monthly=burn_rate_monthly,
        gross_margin=gross_margin,
        runway_days=ConfidenceRange(minimum=min_runway, expected=expected_runway, maximum=max_runway, assumption="Pengeluaran konstan"),
        revenue_consistency=0.8,
        health_score=health_score,
        forecast_30d=forecast,
        narrative=narrative,
        business_type=business_type
    )
    
    return output
